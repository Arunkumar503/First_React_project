



// interface Student{
//     name: string;
//     age: number;
//     password: string | number;
// }
// const studentdata: Student = {
//     name: "Arun Arya",
//     age: 20,
//     password: 12345
// };
// console.log(studentdata.name);
// console.log(studentdata.age);
// console.log(studentdata.password);

// import { useState } from "react";




// primitive data types
// number, string, boolean, null, undefined
// let age:number = 21;
// let name:string = "Arun Arya";
// let isavailable:boolean = true;
// let novalue:null = null;
// let notdefined:undefined = undefined;

// difference between javaScript and TypeScript
// const  [Count,setCount]=useState<number>(0);
// const [count,setCount]=usestate(0);
